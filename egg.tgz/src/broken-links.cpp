// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("broken links\n", stdout);
  return lionss_run_workload("broken-links");
}
