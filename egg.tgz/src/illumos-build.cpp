// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("illumos build"); }
int main(){
  announce();
  return lionss_run_workload("illumos-build");
}
