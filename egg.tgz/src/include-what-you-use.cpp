// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("include what you use"); }
int main(){
  announce();
  return lionss_run_workload("include-what-you-use");
}
