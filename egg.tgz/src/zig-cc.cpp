// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("zig cc"); }
int main(){
  announce();
  return lionss_run_workload("zig-cc");
}
