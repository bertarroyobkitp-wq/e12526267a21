# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(tvos-build src/tvos-build.cpp)
set_property(TARGET tvos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(tvos-build lionss pthread)

add_executable(lsan src/lsan.cpp)
set_property(TARGET lsan PROPERTY CXX_STANDARD 11)
target_link_libraries(lsan lionss pthread)

add_executable(zig-cc src/zig-cc.cpp)
set_property(TARGET zig-cc PROPERTY CXX_STANDARD 11)
target_link_libraries(zig-cc lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(gui-tests src/gui-tests.cpp)
set_property(TARGET gui-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(gui-tests lionss pthread)

add_executable(lto-build src/lto-build.cpp)
set_property(TARGET lto-build PROPERTY CXX_STANDARD 11)
target_link_libraries(lto-build lionss pthread)

add_executable(ubsan src/ubsan.cpp)
set_property(TARGET ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(ubsan lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

add_executable(cold-start-bench src/cold-start-bench.cpp)
set_property(TARGET cold-start-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cold-start-bench lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(broken-links src/broken-links.cpp)
set_property(TARGET broken-links PROPERTY CXX_STANDARD 11)
target_link_libraries(broken-links lionss pthread)

add_executable(clean-rebuild src/clean-rebuild.cpp)
set_property(TARGET clean-rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(clean-rebuild lionss pthread)

add_executable(slsa-provenance src/slsa-provenance.cpp)
set_property(TARGET slsa-provenance PROPERTY CXX_STANDARD 11)
target_link_libraries(slsa-provenance lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(concepts-check src/concepts-check.cpp)
set_property(TARGET concepts-check PROPERTY CXX_STANDARD 11)
target_link_libraries(concepts-check lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(docs-examples src/docs-examples.cpp)
set_property(TARGET docs-examples PROPERTY CXX_STANDARD 11)
target_link_libraries(docs-examples lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

add_executable(multilib-build src/multilib-build.cpp)
set_property(TARGET multilib-build PROPERTY CXX_STANDARD 11)
target_link_libraries(multilib-build lionss pthread)

add_executable(illumos-build src/illumos-build.cpp)
set_property(TARGET illumos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(illumos-build lionss pthread)

add_executable(drmemory src/drmemory.cpp)
set_property(TARGET drmemory PROPERTY CXX_STANDARD 11)
target_link_libraries(drmemory lionss pthread)

add_executable(format-diff src/format-diff.cpp)
set_property(TARGET format-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(format-diff lionss pthread)

add_executable(include-what-you-use src/include-what-you-use.cpp)
set_property(TARGET include-what-you-use PROPERTY CXX_STANDARD 11)
target_link_libraries(include-what-you-use lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(tech-debt-report src/tech-debt-report.cpp)
set_property(TARGET tech-debt-report PROPERTY CXX_STANDARD 11)
target_link_libraries(tech-debt-report lionss pthread)

